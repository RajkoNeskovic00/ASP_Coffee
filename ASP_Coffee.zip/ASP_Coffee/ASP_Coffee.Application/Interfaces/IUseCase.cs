﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASP_Coffee.Application.Interfaces
{
    public interface IUseCase
    {
        int id { get; }
        string Name { get; }
    }
}
