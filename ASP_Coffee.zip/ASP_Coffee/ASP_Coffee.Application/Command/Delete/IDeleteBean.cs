﻿using ASP_Coffee.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASP_Coffee.Application.Command.Delete
{
    public interface IDeleteBean : ICommand<int>
    {
    }
}
