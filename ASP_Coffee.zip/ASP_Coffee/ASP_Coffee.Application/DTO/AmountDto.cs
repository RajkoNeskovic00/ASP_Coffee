﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASP_Coffee.Application.DTO
{
    public class AmountDto
    {
        public int Id { get; set; }
        public int AmountPack { get; set; }
    }
}
